This script assumes that the VisualRBM Tools are in a directory your %PATH%
variable.  We also assume that the folowing MNIST data files are located in the same
directory as the schedule files and the run.bat file:
	
	mnist-train-images.idx
	mnist-train-labels.idx
	mnist-test-images.idx

To run this tutorial and build a classifier for the MNIST dataset, simply run
run.bat
